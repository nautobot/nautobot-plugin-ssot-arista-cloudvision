"""Unit tests for nautobot_ssot plugin."""
